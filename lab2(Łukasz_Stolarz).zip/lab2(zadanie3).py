def funckja(x:int): #funckja x^2
    return x*x

def du(funckja,xp: int=-1,xk: int=1,delta: int=10): #xp poczatek przedzialu xk koniec przedzialu o domylsnych wartosciach 1 i -1 delta ilosc korkow , funkcja wykonuje x*x
    dx=(xk-xp)/delta
    while xp <= xk:
        print(xp,funckja(xp))
        xp=xp+dx
du(funckja,0,10,10)              

def printCenert(tekst: str,dlugosc:int=20): 
    x=len(tekst)
    od=(dlugosc-x)/2
    y=0
    while y <od:
        y=y+1
        print('*',end='')
    print(tekst,end='')
    y=0
    while y<(dlugosc-x-od):
        y=y+1
        print('*',end='')
def k(napis):
    for x in napis :
        printCenert(x)
        print("\n")
print("Aby zakonczyc progra napisz 0001 \n")       
napis=""
tymczas=[]
while napis !="x" :
    napis=input("podaj tekst do wycentorwania:\n")
    if napis=='0001' :
        break
    tymczas.append(napis)
print(tymczas)

k(tymczas)

def czy_pierwsza(n):
    if n == 2:
        print ('jest to liczba pierwsza')
    if n % 2 == 0 or n <= 1:
        return False

    pierw = int(n**0.5) + 1
    for dzielnik in range(3, pierw, 2):
        if n % dzielnik == 0:
            return False
    print ('jest to liczba pierwsza') #ulepszona wersja liczby pierwszej z lab1.Sprawdzam tylko do pierw 
def mer():
    x=1
    while x<=31:
     print(2**x-1,':')
     czy_pierwsza(2**x-1)
     x=x+1
mer()

import random
def k4():
 return random.randint(1, 4)
def k8():
 return random.randint(1, 8)
def k10():
 return random.randint(1, 10)
def k20():
 return random.randint(1, 20)

def getDice(x: str):
    if x == 'k4':
     return k4()
    elif x == 'k8':
     return k8()
    elif x== 'k10':
     return k10()
    elif x== 'k20':
     return k20()
    else:
     print('blad nie ma takiej mozliwosci')
def roll(format:str):
    z=format.split("k") #Zwraca listę słów ciągu s 
    x=int(z[0])
    y=int(z[1])
    s=0
    for i in range(0,x):
        s=s+getDice("k"+str(y))
    print(s)     
y=str(input("wybierz funkcjie k4/k8/k10/k20"))
print(getDice(y))
print(k4())
roll("5k10") #5 razy wywola funkcje k10



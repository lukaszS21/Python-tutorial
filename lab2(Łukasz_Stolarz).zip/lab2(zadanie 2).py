def printCenert(tekst: str,dlugosc:int=80): 
    x=len(tekst) #dlugosc tekstu
    od=(dlugosc-x)/2
    y=0
    while y <od:
        y=y+1
        print('*',end='')
    print(tekst,end='')
    y=0
    while y<od:
        y=y+1
        print('*',end='')
x=input("podaj tekst do wycentorwania:\n")# pobiera stringa z klawiatury
y=int(input("podaj dlugosc tekstu:\n"))# pobiera inta z klawiatury
printCenert(x, y)

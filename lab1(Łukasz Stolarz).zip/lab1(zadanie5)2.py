def kli(tekst):
    samo=['o','i','y','u','ą','a','e']
    nowy=''
    for x in tekst:
        if x in samo:
            nowy=nowy+"a"
        else:
            nowy=nowy+x
    print(nowy) #pobieram tekst przechodze po nim jesli pozycja x tekstu jest samogloska to do nowego tekstu dodaje a zamiast x w przeciwnym wypadku dokleiam x
napis=input("podaj tekst\n")
tekst='ols'
print(napis)
kli(napis)

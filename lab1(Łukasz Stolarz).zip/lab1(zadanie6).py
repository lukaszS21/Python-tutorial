import datetime
dzis=datetime.datetime.now() #pobieram dziesiejsza date
print(dzis.strftime("%A"))
x=dzis.strftime("%A")#pobieram dzisiejszy dzien tygodnia po ang
x=x.lower()#zmniejszam litery z dnia tygodnia
dz=['Monday','Tuesday']
for x in [0,1]:
    tekst=input("podaj dzien tygodnia \n")
    tekst=tekst.lower()
    if x=="monday":
        x="poniedziałek"
    elif x=="tuesday":
        x="wtorek"
    elif x=="wednesday":
        x="środa"
    elif x=="thursday":
        x="czwartek"
    elif x=="friday":
        x="piatek"
    elif x=="saturday":
        x="sobota"
    elif x=="sunday":
        x="niedziela"
        
    if x==tekst:
        print('brawo dzis naprawde jest ' + tekst)
        break
    else:
        print("zly dzien tygodnia")
        if x==1:
         print("panei nie pij juz pan")

import math
x=3
y=2
liczba=4
print('x=',x)
print('Wynik dzielenia do liczby całkowitej x // y =', x // y)
# Wynik: Wynik potęgowania x ** y = 9
print('Wynik potęgowania x ** y =', x ** y)
z=math.sqrt(liczba)
print('wynik pierwistkowania liczby=',z)
s = 'First line.\nSecond line.'  # \n przejscie do nowej lini
print(s)  # wypisuje s
p='un'+ 3*'zycie jest ciezkie\n' #za pomoca + łaczy sie 2 teksty
print(p)
word = 'Python'
print(word[0])  # wypisze pozycje 0 word
print(word[5])  # wypisze pozycje 5 word
print(word[-1]) #idzie od konca(n)
print(word[-6])

print(word[0:2])
#analogicznie listy

rok=int(input("Podaj rok: "))
# input zwraca tekst (string)
# int() -> rzutowanie na liczbę całkowitą domyslnie jest string
if rok%4: # jesli reszta z dzielenia podanego rokujest 0 jest to rok przestepny
 tekst="Rok "+str(rok)+" nie jest przestepny"
 print(tekst)
else:
 tekst="Rok "+str(rok)+"  jest przestepny"
 print(tekst)

def primes(x):
    i=2      
    for i in range(2, x): 
        if x % i == 0:
          print (x, " nie jest liczba pierwsza\n ")
          break
        else:
           print (x, " jest liczbą pierwszą\n")
           break
y=int(input("podaj liczbe\n"))
primes(y)


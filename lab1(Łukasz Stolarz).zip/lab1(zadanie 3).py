#from numpy import arange
import math
#for x in arange(-1.0, 1.0, 0.1):
 #print("{0:8.2f} {1:+10.6f} {1:12.2e}".format(x, math.sin(x)))
print("sin(x)")
for y in range (-10,10,1): #range nie dziala z flotami dlatego po wejsciu w petle trzeba dzielic y przez 10 lub inna wartosc tak aby dane dla sin sie zgadzaly
    
    y=y/10
    print("{0:8.2f} {1:+10.6f} {1:12.2e}".format(y, math.sin(y)))#sposob modyfikowania wypisywania tekstu

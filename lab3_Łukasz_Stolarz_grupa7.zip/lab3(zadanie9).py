def lis(x:int):
    nowa=[]
    
    for z in range(0,x,1): #od 0 do x co 1
        tymczas=[]
        for c in range(0,x,1):
            if z%2==0:
                if c%2==0:
                    tymczas.append(1)
                else:
                    tymczas.append(0)
            else:
                if c%2==0:
                    tymczas.append(0)
                else:
                    tymczas.append(1)
        nowa.append(tymczas)
    return(nowa)


def wypisz(x:list):
    print("tablica:\n",x)
    for z in x:
        print(z)
        
wypisz(lis(4))

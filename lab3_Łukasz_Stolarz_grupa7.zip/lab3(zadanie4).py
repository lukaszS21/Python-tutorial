def lis(x:list,y:list):
    nowa=[]
    z=0
    if len(x)<len(y):
        for c in range(len(x)):
            nowa.append (x[z]+y[z])
            z=z+1
        print(nowa)
    else:
        for c in range(len(y)):
            nowa.append (x[z]+y[z])
            z=z+1
        print(nowa)
    

k1=[2,1,2,3,2,2,1]
k2=[2,5,3,5]
lis(k1,k2)

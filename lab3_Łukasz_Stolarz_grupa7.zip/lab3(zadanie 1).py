def fun(x:list):
    print("max=",max(x),"\n")
    print("min=",min(x),"\n")
    suma=0
    z=0
    sumakoncowa=0
    ilosc=len(x)
    for y in x:
        z=z+1
        suma=(suma+y)
    sumakoncowa=suma/z
    print("suma=",sumakoncowa)
o2=[2,2]         
ol=[1,2,3,2,6,9,11,13,2,1]
fun(ol)
#liczy max i min oraz ich sume arytmetyczna

def fun(x:list):
    samogloski=0
    lista=[]
    for z in x:
        for znak in z:
            if znak in "aiueoy":
                samogloski=samogloski+1
        if samogloski%2==0:
                lista.append(z)
                samogloski=0
    print(lista)
     
      
s=["Nie lubie Mo","robot","olaa"]
fun(s)

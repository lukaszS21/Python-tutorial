def lis(x:list,odstep:int):
    v=odstep
    for z in range(1,len(x)//odstep+1,1):
        x.insert(v,0)
        v=v+odstep+1
    print(x)

o1=[2,3,1,34,2,3,2,1,6,7,4,-2]
lis(o1,3)

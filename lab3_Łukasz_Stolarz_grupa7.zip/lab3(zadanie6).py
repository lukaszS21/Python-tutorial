def lis(x:list):
    x.sort()
    nowa=[]
    nowa2=[]
    nowa=[x[y] for y in range(3)]
    x.reverse()
    nowa2=[x[y] for y in range(3)]
    print(x)
    nowa.reverse()
    nowa=nowa+nowa2
    print(nowa)
    
    

o1=[0,1,-5,8,14,9,6]
lis(o1)

    

def lis(x:list):
    nowa=[]
    z=0
    for y in x:
        if y is x[0]:
            nowa.append(x[0])
        elif y is x[len(x)-1]:
            nowa.append(x[len(x)-1])
        else:
            nowa.append((x[z-1]+y+x[z+1])/3)
        z=z+1
    print(nowa)
o1=[2,2,4,5,8]
lis(o1)
        

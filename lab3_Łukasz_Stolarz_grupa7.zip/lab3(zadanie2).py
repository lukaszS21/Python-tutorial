def lis(x:list):
    x=[y**2 for y in range(10)]
    print(x,"\n",)
    x=[y**3 for y in range(10)]
    print(x,"\n",)
    x=[y**4 for y in range(10)]
    print(x,"\n",)
o1=[]
lis(o1)
    


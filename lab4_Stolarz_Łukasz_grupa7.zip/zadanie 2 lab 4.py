import math
def krotka(x,y):
    return(y,x+y)
k=(1,2)
print(krotka(*k))

def fibonaci(max):
    x=1
    y=1
    for i in range(1,max+1):
        print("Iteracja:",i,": ",krotka(x,y))
        x,y=krotka(x,y)
    
fibonaci(10)

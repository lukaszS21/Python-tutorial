from random import seed, randint
tab2=[]
tab1=[]
for c in range(10):
    for r in range(10):
         tab1.append("0")
    tab2.append(tab1)
    tab1=[]
for x in range(10):
        tab2[randint(0,9)][randint(0,9)]= '1'
        
strzaly=[]
print(tab2)
def funkcja():
    for x in range (0,9):
        for y in range(0,9):
            if tab2[x][y] == "1":
                print("Twoje strzaly: ",strzaly)
                krotka=input('Podaj wspolrzedne w formacie [x,y] ')
                if krotka in strzaly:
                    print("ten punkt juz wpisales")
                    funkcja()
                elif tab2[int(krotka[1])][int(krotka[3])] == "1":
                    tab2[int(krotka[1])][int(krotka[3])] = "0"
                    print("Trafiony !")
                    strzaly.append(krotka)
                    funkcja() 
                else:
                    print("Pudlo !")
                    strzaly.append(krotka)
                    funkcja()
    
funkcja()

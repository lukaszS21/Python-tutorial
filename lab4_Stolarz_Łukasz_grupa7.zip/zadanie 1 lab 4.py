import math

def kro():
    sinn=0
    coss=0
    z=0
    for y in range (0,91,1):
        tup=()
        sinn = math.sin(math.radians(y))
        coss = math.cos(math.radians(y))
        tup=(sinn,coss)
        print("kąt:",y,";","sin:",tup[z],";","cos:",tup[z+1])
    
        

kro()


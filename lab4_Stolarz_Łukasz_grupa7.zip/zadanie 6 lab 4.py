import math
def fun(slownik):
    wynik={key: 'sen wieczny :(' if value>200 else 8/(math.log10(value)) for key, value in slownik.items() if value>0}
    print(wynik)
slownik={'lukasz':30,'michal':520,'ola':-25,'adam':3826,'kora':10}
fun(slownik)



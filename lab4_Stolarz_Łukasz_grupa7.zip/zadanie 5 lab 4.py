def srednia_ponizej_3(dziennik):
    for k,wartosc in dziennik.items():
        srednia=0
        for c,d in wartosc.items():
            srednia=srednia+d
        srednia=srednia/2
        if srednia <=3:
            print(k," ma srednia")
            print(srednia)

def srednia_kategoria(dziennik):
     srednia1=0
     srednia2=0
     srednia3=0
     for k,wartosc in dziennik.items():
        for c,d in wartosc.items():
            if c=='python':
                srednia1=srednia1+d
                
                
            if c=='lisp':
                srednia2=srednia2+d
                
            if c=='odpowiedz':
                srednia3=srednia3+d
     srednia1=srednia1/2  
     print('srednia z pythona',srednia1)
     print('srednia z lispa',srednia2)
     print('srednia z odpowiedzi',srednia3)    
        
        
            
        
dziennik={'Mietek':{'python':2,'lisp':3},'ola':{'python':3,'odpowiedz':4}}

srednia_ponizej_3(dziennik)
srednia_kategoria(dziennik)

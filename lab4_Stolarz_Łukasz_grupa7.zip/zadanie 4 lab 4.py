def ol(oceny):
    for key in sorted(oceny):
        print (key)

def ol2(oceny):
    print(oceny)
oceny={
    "Michal" : 3 ,
    "Bratek" : 6 ,
    "Pawel"  : 5 ,
    "Arek" :1 ,
    }
ol(oceny)
ol2(oceny)

